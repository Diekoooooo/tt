## Install
```bash
git clone https://github.com/The404Hacking/TabChi.git && cd tabchi && chmod 777 install.sh && chmod 777 telegamer.sh && ./install.sh && lua creator.lua
```
## Create a bot!
```
lua creator.lua
Auto Detected Tabchi ID : 0
Enter Full Sudo ID : id9raqami tel
Done!
New Tabchi Created...
ID : 0
Full Sudo : id9raqmi tel
Run : ./tabchi-0.sh
```
Enter your telegram id in "Full Sudo ID" part
Goto [User Info Bot](https://t.me/userinfobot)

## Run
Use `./tabchi-ID.sh` to run your bot normaly or use `screen ./tabchi-ID.sh` for auto launch mode (put tabchi-id in ID part)

## Autolaunch
use `./start.sh ` for Autolaunch


